import { useEffect, useMemo, useRef, useState, type FormEvent } from "react";
import { ChevronDown, ChevronUp, Copy, Download, Eye, KeyRound, Pencil, Plus, Power, Search, Trash2 } from "lucide-react";
import { useAuth } from "../context/AuthContext";
import { api, ApiError } from "../services/api";
import Modal from "../components/billing/Modal";
import { todayISO } from "../types/billing";
import {
  ACTIONS,
  MODULES,
  effectivePermissions,
  normalizePermissions,
  type Action,
  type Module,
  type Permissions,
  type Role,
  type User,
} from "../types/access";

type ManagedUser = User;
const failure = (e: unknown) => (e instanceof ApiError ? e.message : "Couldn't reach the server. Check your connection and try again.");
const shownTime = (t: string | null) => (t ? t.slice(0, 16) : "Never");

interface UserFormData {
  name: string;
  email: string;
  phone: string;
  roleId: string;
  permissions?: Permissions; // set only when privileges are customised for this user
}

const clone = (p: Permissions): Permissions => JSON.parse(JSON.stringify(p));
const countGranted = (p: Permissions) => MODULES.reduce((n, m) => n + ACTIONS.filter((a) => p[m][a]).length, 0);
const TOTAL_PERMS = MODULES.length * ACTIONS.length;

/** Privilege grid. "view" is the base permission: ticking anything else ticks view, unticking view clears the row. */
function PermissionMatrix({ value, onChange }: { value: Permissions; onChange: (p: Permissions) => void }) {
  const toggle = (m: Module, a: Action) => {
    const next = clone(value);
    const on = !value[m][a];
    next[m][a] = on;
    if (a === "view" && !on) ACTIONS.forEach((x) => (next[m][x] = false));
    if (a !== "view" && on) next[m].view = true;
    onChange(next);
  };
  const toggleRow = (m: Module) => {
    const all = ACTIONS.every((a) => value[m][a]);
    onChange({ ...value, [m]: { view: !all, create: !all, edit: !all, delete: !all } });
  };

  return (
    <div className="overflow-x-auto rounded-lg border border-slate-200">
      <table className="w-full text-left text-sm">
        <thead className="bg-slate-50 text-xs uppercase text-slate-500">
          <tr>
            <th className="px-4 py-2">Module</th>
            {ACTIONS.map((a) => (
              <th key={a} className="px-4 py-2 text-center">{a}</th>
            ))}
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-100">
          {MODULES.map((m) => (
            <tr key={m}>
              <td className="px-4 py-1.5">
                <button type="button" onClick={() => toggleRow(m)} title="Toggle all actions for this module" className="font-medium text-slate-700 hover:text-blue-600">{m}</button>
              </td>
              {ACTIONS.map((a) => (
                <td key={a} className="px-4 py-1.5 text-center">
                  <input type="checkbox" checked={value[m][a]} onChange={() => toggle(m, a)} aria-label={`${a} ${m}`} className="h-4 w-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500" />
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

const ADMIN_ROLE_ID = "r-admin";
const PAGE_SIZE = 10;

const inputClass =
  "w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500";

const isEmail = (s: string) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(s);
const hasLoggedIn = (u: ManagedUser) => !!u.lastLogin;

// Spreadsheet apps run text starting with = + - @ as a formula, so neutralise those cells.
const csvCell = (v: string) => {
  const safe = /^[=+\-@]/.test(v) ? `'${v}` : v;
  return `"${safe.replace(/"/g, '""')}"`;
};

type SortKey = "name" | "role" | "lastLogin" | "status";

function CredentialsModal({ title, user, password, onClose }: { title: string; user: ManagedUser; password: string; onClose: () => void }) {
  const [copied, setCopied] = useState(false);

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(`Email: ${user.email}\nTemporary password: ${password}`);
      setCopied(true);
    } catch {
      /* clipboard blocked: the values are visible to copy by hand */
    }
  };

  return (
    <Modal title={title} onClose={onClose}>
      <div className="space-y-4 text-sm">
        <p className="text-slate-600">
          Share these with <span className="font-medium text-slate-800">{user.name}</span>. The password is shown only now, and they'll be asked to change it at first login.
        </p>
        <div className="space-y-2 rounded-lg bg-slate-50 p-4 font-mono text-sm">
          <p><span className="text-slate-500">Email: </span>{user.email}</p>
          <p><span className="text-slate-500">Password: </span>{password}</p>
        </div>
        <div className="flex justify-end gap-3">
          <button onClick={copy} className="flex items-center gap-2 rounded-lg border border-slate-200 px-4 py-2 font-medium text-slate-700 hover:bg-slate-50">
            <Copy size={15} /> {copied ? "Copied" : "Copy"}
          </button>
          <button onClick={onClose} className="rounded-lg bg-blue-600 px-5 py-2 font-medium text-white hover:bg-blue-700">Done</button>
        </div>
      </div>
    </Modal>
  );
}

function UserDetail({ user, roles, onClose }: { user: ManagedUser; roles: Role[]; onClose: () => void }) {
  const role = roles.find((r) => r.id === user.roleId);
  const perms = role ? effectivePermissions(user, roles) : null;
  const custom = !!user.permissions && user.roleId !== ADMIN_ROLE_ID;
  return (
    <Modal title={user.name} onClose={onClose} wide>
      <div className="space-y-5 text-sm">
        <dl className="grid gap-4 sm:grid-cols-3">
          <div><dt className="text-xs uppercase text-slate-400">Email</dt><dd className="text-slate-800">{user.email}</dd></div>
          <div><dt className="text-xs uppercase text-slate-400">Phone</dt><dd className="text-slate-800">{user.phone ?? "—"}</dd></div>
          <div><dt className="text-xs uppercase text-slate-400">Role</dt><dd className="text-slate-800">{role?.name ?? "—"}</dd></div>
          <div><dt className="text-xs uppercase text-slate-400">Status</dt><dd className="text-slate-800">{user.active ? "Active" : "Inactive"}</dd></div>
          <div><dt className="text-xs uppercase text-slate-400">Last login</dt><dd className="text-slate-800">{shownTime(user.lastLogin)}</dd></div>
          <div><dt className="text-xs uppercase text-slate-400">Created</dt><dd className="text-slate-800">{user.createdAt}</dd></div>
        </dl>

        <section className="rounded-lg border border-slate-200">
          <h3 className="flex items-center justify-between border-b border-slate-200 px-4 py-2 font-semibold text-slate-700">
            What this user can do
            <span className="text-xs font-normal text-slate-500">{custom ? "Custom privileges set for this user" : `Inherited from the ${role?.name ?? "—"} role`}</span>
          </h3>
          {perms ? (
            <table className="w-full text-left">
              <thead className="bg-slate-50 text-xs uppercase text-slate-500">
                <tr>
                  <th className="px-4 py-2">Module</th>
                  {ACTIONS.map((a) => (
                    <th key={a} className="px-4 py-2 text-center">{a}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {MODULES.map((m) => (
                  <tr key={m}>
                    <td className="px-4 py-1.5 text-slate-700">{m}</td>
                    {ACTIONS.map((a) => (
                      <td key={a} className={`px-4 py-1.5 text-center ${perms[m][a] ? "text-emerald-600" : "text-slate-300"}`}>
                        {perms[m][a] ? "✓" : "–"}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          ) : (
            <p className="px-4 py-3 text-slate-400">This user's role no longer exists.</p>
          )}
        </section>
        {!user.active && <p className="text-xs text-slate-500">This account is inactive, so these permissions are not currently usable.</p>}
      </div>
    </Modal>
  );
}

function UserForm({
  user,
  users,
  roles,
  isSelf,
  lockedAdmin,
  onSave,
  onClose,
}: {
  user: ManagedUser | null; // null = new
  users: ManagedUser[];
  roles: Role[];
  isSelf: boolean;
  lockedAdmin: boolean;
  onSave: (data: UserFormData) => Promise<string | null>;
  onClose: () => void;
}) {
  const [name, setName] = useState(user?.name ?? "");
  const [email, setEmail] = useState(user?.email ?? "");
  const [phone, setPhone] = useState(user?.phone ?? "");
  const [roleId, setRoleId] = useState(user?.roleId ?? (roles.find((r) => r.id !== ADMIN_ROLE_ID) ?? roles[0]).id);
  const [custom, setCustom] = useState(!!user?.permissions);
  const roleDefaults = (id: string) => clone(roles.find((r) => r.id === id)?.permissions ?? roles[0].permissions);
  const [perms, setPerms] = useState<Permissions>(() => user?.permissions ?? roleDefaults(user?.roleId ?? roleId));
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);

  const roleLocked = isSelf || lockedAdmin;
  const isAdminRole = roleId === ADMIN_ROLE_ID;
  const selectedRole = roles.find((r) => r.id === roleId);

  const changeRole = (id: string) => {
    setRoleId(id);
    // A customised grid starts from the role you pick, so nothing is silently lost when switching.
    if (!custom) setPerms(roleDefaults(id));
  };

  const setCustomMode = (on: boolean) => {
    setCustom(on);
    if (on && !user?.permissions) setPerms(roleDefaults(roleId));
  };

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    const cleanEmail = email.trim().toLowerCase();
    if (!name.trim()) return setError("Full name is required.");
    if (!isEmail(cleanEmail)) return setError("Enter a valid email address.");
    if (users.some((u) => u.id !== user?.id && u.email.toLowerCase() === cleanEmail)) return setError("Another user already has that email.");
    if (phone.trim() && phone.replace(/\D/g, "").length < 7) return setError("Enter a valid phone number or leave it blank.");
    const useCustom = custom && !isAdminRole;
    if (useCustom && countGranted(perms) === 0) return setError("Grant at least one privilege, or switch back to the role's permissions.");

    setSaving(true);
    const problem = await onSave({
      name: name.trim(),
      email: cleanEmail,
      phone: phone.trim(),
      roleId,
      permissions: useCustom ? perms : undefined,
    });
    setSaving(false);
    if (problem) setError(problem);
  };

  return (
    <Modal title={user ? `Edit ${user.name}` : "Add User"} onClose={onClose} wide>
      <form onSubmit={submit} className="space-y-4">
        <div className="grid gap-4 sm:grid-cols-2">
          <label className="block text-sm">
            <span className="mb-1 block text-slate-600">Full name</span>
            <input className={inputClass} value={name} onChange={(e) => setName(e.target.value)} autoFocus />
          </label>
          <label className="block text-sm">
            <span className="mb-1 block text-slate-600">Email (used to sign in)</span>
            <input type="email" className={inputClass} value={email} onChange={(e) => setEmail(e.target.value)} />
          </label>
          <label className="block text-sm">
            <span className="mb-1 block text-slate-600">Phone (optional)</span>
            <input className={inputClass} value={phone} onChange={(e) => setPhone(e.target.value)} />
          </label>
          <label className="block text-sm">
            <span className="mb-1 block text-slate-600">Role</span>
            <select className={inputClass} value={roleId} onChange={(e) => changeRole(e.target.value)} disabled={roleLocked}>
              {roles.map((r) => (
                <option key={r.id} value={r.id}>{r.name}</option>
              ))}
            </select>
          </label>
        </div>
        {roleLocked && (
          <p className="text-xs text-slate-500">
            {isSelf ? "You can't change your own role." : "This is the only active administrator, so the role can't be changed."}
          </p>
        )}

        <section className="rounded-lg border border-slate-200">
          <div className="border-b border-slate-200 px-4 py-3">
            <h3 className="text-sm font-semibold text-slate-700">Privileges</h3>
            <p className="text-xs text-slate-500">Decide what this person can view, create, edit and delete in each module.</p>
          </div>
          {isAdminRole ? (
            <p className="px-4 py-3 text-sm text-slate-600">Administrators always have full access to every module, including user and role management.</p>
          ) : (
            <div className="space-y-3 p-4">
              <div className="flex flex-wrap gap-4 text-sm text-slate-700">
                <label className="flex items-center gap-2">
                  <input type="radio" name="priv-mode" checked={!custom} onChange={() => setCustomMode(false)} className="text-blue-600" />
                  Use the {selectedRole?.name ?? "role"} role's permissions
                </label>
                <label className="flex items-center gap-2">
                  <input type="radio" name="priv-mode" checked={custom} onChange={() => setCustomMode(true)} className="text-blue-600" />
                  Choose privileges for this user
                </label>
              </div>

              {custom ? (
                <>
                  <div className="flex flex-wrap items-center gap-2 text-xs">
                    <span className="text-slate-500">Quick set:</span>
                    <button type="button" onClick={() => setPerms(roleDefaults(roleId))} className="rounded-full border border-slate-200 px-3 py-1 font-medium text-slate-600 hover:bg-slate-50">Reset to {selectedRole?.name} role</button>
                    <button type="button" onClick={() => setPerms(Object.fromEntries(MODULES.map((m) => [m, { view: true, create: false, edit: false, delete: false }])) as Permissions)} className="rounded-full border border-slate-200 px-3 py-1 font-medium text-slate-600 hover:bg-slate-50">Read-only</button>
                    <button type="button" onClick={() => setPerms(Object.fromEntries(MODULES.map((m) => [m, { view: false, create: false, edit: false, delete: false }])) as Permissions)} className="rounded-full border border-slate-200 px-3 py-1 font-medium text-slate-600 hover:bg-slate-50">Clear all</button>
                    <span className="ml-auto text-slate-500">{countGranted(perms)} of {TOTAL_PERMS} granted</span>
                  </div>
                  <PermissionMatrix value={perms} onChange={setPerms} />
                  <p className="text-xs text-slate-400">Create, edit and delete need view access, so ticking any of them also ticks view. Click a module name to toggle its whole row. Changing the role later won't overwrite these choices.</p>
                </>
              ) : (
                <p className="text-xs text-slate-500">
                  {selectedRole ? `${countGranted(selectedRole.permissions)} of ${TOTAL_PERMS} permissions, kept in step if the role is edited on the Roles page.` : ""}
                </p>
              )}
            </div>
          )}
        </section>

        {!user && <p className="text-xs text-slate-500">A temporary password is created for you when you save. It is shown once, and they must change it at first sign-in.</p>}

        {error && <p role="alert" className="text-sm text-rose-600">{error}</p>}

        <div className="flex justify-end gap-3">
          <button type="button" onClick={onClose} className="rounded-lg border border-slate-200 px-4 py-2 text-sm font-medium text-slate-600 hover:bg-slate-50">Cancel</button>
          <button type="submit" disabled={saving} className="rounded-lg bg-blue-600 px-5 py-2 text-sm font-medium text-white hover:bg-blue-700 disabled:opacity-60">{user ? "Save Changes" : "Create User"}</button>
        </div>
      </form>
    </Modal>
  );
}

export default function Users() {
  const { user: me } = useAuth();
  const [roles, setRoles] = useState<Role[]>([]);
  const [users, setUsers] = useState<ManagedUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState("");
  const [query, setQuery] = useState("");
  const [roleFilter, setRoleFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState<"all" | "active" | "inactive" | "never">("all");
  const [sort, setSort] = useState<{ key: SortKey; dir: 1 | -1 }>({ key: "name", dir: 1 });
  const [page, setPage] = useState(1);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [editing, setEditing] = useState<ManagedUser | "new" | null>(null);
  const [viewing, setViewing] = useState<ManagedUser | null>(null);
  const [credentials, setCredentials] = useState<{ title: string; user: ManagedUser; password: string } | null>(null);
  const [notice, setNotice] = useState("");
  const noticeTimer = useRef<number | undefined>(undefined);

  useEffect(() => () => window.clearTimeout(noticeTimer.current), []);

  const reload = async () => {
    setLoadError("");
    try {
      const [r, u] = await Promise.all([api.get<{ roles: Role[] }>("/roles"), api.get<{ users: ManagedUser[] }>("/users")]);
      setRoles(r.roles.map((x) => ({ ...x, permissions: normalizePermissions(x.permissions) })));
      setUsers(u.users.map((x) => (x.permissions ? { ...x, permissions: normalizePermissions(x.permissions) } : x)));
    } catch (e) {
      setLoadError(failure(e));
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    void reload();
  }, []);

  const roleName = (id: string) => roles.find((r) => r.id === id)?.name ?? "—";

  const activeAdmins = users.filter((u) => u.active && u.roleId === ADMIN_ROLE_ID).length;
  const isLastActiveAdmin = (u: ManagedUser) => u.active && u.roleId === ADMIN_ROLE_ID && activeAdmins <= 1;

  const stats = useMemo(
    () => ({
      total: users.length,
      active: users.filter((u) => u.active).length,
      inactive: users.filter((u) => !u.active).length,
      admins: users.filter((u) => u.roleId === ADMIN_ROLE_ID).length,
      pending: users.filter((u) => u.mustChangePassword).length,
    }),
    [users]
  );

  const sortValue = (u: ManagedUser): string =>
    sort.key === "name" ? u.name.toLowerCase() : sort.key === "role" ? roleName(u.roleId).toLowerCase() : sort.key === "lastLogin" ? (u.lastLogin ?? "") : u.active ? "a" : "b";

  const filtered = users
    .filter((u) => roleFilter === "all" || u.roleId === roleFilter)
    .filter((u) => statusFilter === "all" || (statusFilter === "active" ? u.active : statusFilter === "inactive" ? !u.active : !hasLoggedIn(u)))
    .filter((u) => {
      const q = query.trim().toLowerCase();
      return !q || u.name.toLowerCase().includes(q) || u.email.toLowerCase().includes(q);
    })
    .sort((a, b) => sortValue(a).localeCompare(sortValue(b)) * sort.dir);

  const pageCount = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const safePage = Math.min(page, pageCount);
  const pageRows = filtered.slice((safePage - 1) * PAGE_SIZE, safePage * PAGE_SIZE);
  const allOnPage = pageRows.length > 0 && pageRows.every((u) => selected.has(u.id));

  const flash = (msg: string) => {
    setNotice(msg);
    window.clearTimeout(noticeTimer.current);
    noticeTimer.current = window.setTimeout(() => setNotice(""), 3500);
  };

  const sortBy = (key: SortKey) => setSort((s) => (s.key === key ? { key, dir: s.dir === 1 ? -1 : 1 } : { key, dir: 1 }));
  const SortIcon = ({ k }: { k: SortKey }) => (sort.key === k ? sort.dir === 1 ? <ChevronUp size={12} /> : <ChevronDown size={12} /> : null);
  const sortable = (k: SortKey, label: string) => (
    <th className="px-5 py-3" aria-sort={sort.key === k ? (sort.dir === 1 ? "ascending" : "descending") : "none"}>
      <button onClick={() => sortBy(k)} className="flex items-center gap-1 font-semibold uppercase hover:text-blue-600">
        {label} <SortIcon k={k} />
      </button>
    </th>
  );

  const toggleRow = (id: string) =>
    setSelected((s) => {
      const next = new Set(s);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });

  const togglePage = () =>
    setSelected((s) => {
      const next = new Set(s);
      pageRows.forEach((u) => (allOnPage ? next.delete(u.id) : next.add(u.id)));
      return next;
    });

  const save = async (data: UserFormData): Promise<string | null> => {
    const body = { name: data.name, email: data.email, phone: data.phone, roleId: data.roleId, permissions: data.permissions ?? null };
    try {
      if (editing === "new") {
        const r = await api.post<{ user: ManagedUser; temporaryPassword: string }>("/users", body);
        await reload();
        setEditing(null);
        setCredentials({ title: "User created", user: r.user, password: r.temporaryPassword });
        return null;
      }
      if (editing) {
        if (editing.id === me?.id && data.roleId !== editing.roleId) return "You can't change your own role.";
        if (isLastActiveAdmin(editing) && data.roleId !== ADMIN_ROLE_ID) return "This is the only active administrator, so their role can't be changed.";
        await api.put(`/users/${editing.id}`, body);
        await reload();
        setEditing(null);
        flash(`${data.name} updated. Privilege changes apply the next time they sign in.`);
      }
      return null;
    } catch (e) {
      return failure(e);
    }
  };

  const setActive = async (u: ManagedUser, active: boolean) => {
    await api.put(`/users/${u.id}`, { active });
  };

  const toggleActive = async (u: ManagedUser) => {
    if (u.id === me?.id) return flash("You can't deactivate your own account.");
    if (isLastActiveAdmin(u)) return flash("You can't deactivate the only active administrator.");
    try {
      await setActive(u, !u.active);
      await reload();
      flash(`${u.name} ${u.active ? "deactivated" : "activated"}.`);
    } catch (e) {
      flash(failure(e));
    }
  };

  const bulkSetActive = async (active: boolean) => {
    const targets = users.filter((u) => selected.has(u.id) && u.active !== active && u.id !== me?.id);
    if (targets.length === 0) return flash(active ? "Nothing to activate (your own account is skipped)." : "Nothing to deactivate (your own account is skipped).");
    if (!active) {
      const ids = new Set(targets.map((u) => u.id));
      const adminsLeft = users.filter((u) => u.active && u.roleId === ADMIN_ROLE_ID && !ids.has(u.id)).length;
      if (adminsLeft === 0) return flash("That would leave no active administrator.");
    }
    let done = 0;
    try {
      for (const u of targets) {
        await setActive(u, active);
        done++;
      }
    } catch (e) {
      await reload();
      return flash(`${done} of ${targets.length} done. ${failure(e)}`);
    }
    await reload();
    setSelected(new Set());
    flash(`${targets.length} user(s) ${active ? "activated" : "deactivated"}.`);
  };

  const resetPassword = async (u: ManagedUser) => {
    if (!window.confirm(`Reset the password for ${u.name}?`)) return;
    try {
      const r = await api.post<{ temporaryPassword: string }>(`/users/${u.id}/reset-password`);
      await reload();
      setCredentials({ title: "Password reset", user: u, password: r.temporaryPassword });
    } catch (e) {
      flash(failure(e));
    }
  };

  const remove = async (u: ManagedUser) => {
    if (u.id === me?.id) return flash("You can't delete your own account.");
    if (isLastActiveAdmin(u)) return flash("You can't delete the only active administrator.");
    if (!window.confirm(`Delete ${u.name}? This can't be undone. Deactivating keeps their history.`)) return;
    try {
      await api.del(`/users/${u.id}`);
      await reload();
      setSelected((s) => {
        const next = new Set(s);
        next.delete(u.id);
        return next;
      });
      flash(`${u.name} deleted.`);
    } catch (e) {
      flash(failure(e));
    }
  };

  const exportCsv = () => {
    const header = ["Name", "Email", "Phone", "Role", "Status", "Last login", "Created"];
    const lines = filtered.map((u) => [u.name, u.email, u.phone ?? "", roleName(u.roleId), u.active ? "Active" : "Inactive", shownTime(u.lastLogin), u.createdAt].map(csvCell).join(","));
    const blob = new Blob([[header.map(csvCell).join(","), ...lines].join("\n")], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `users-${todayISO()}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const cards = [
    { label: "Total users", value: stats.total },
    { label: "Active", value: stats.active },
    { label: "Inactive", value: stats.inactive },
    { label: "Administrators", value: stats.admins },
    { label: "Password change pending", value: stats.pending },
  ];

  if (loading) return <p className="text-sm text-slate-500">Loading users from the database…</p>;
  if (loadError)
    return (
      <div className="space-y-3 rounded-xl border border-rose-200 bg-rose-50 p-5 text-sm text-rose-700">
        <p role="alert">{loadError}</p>
        <button onClick={() => { setLoading(true); void reload(); }} className="rounded-lg bg-white px-4 py-2 font-medium text-slate-700 ring-1 ring-slate-200 hover:bg-slate-50">Try again</button>
      </div>
    );

  return (
    <div className="space-y-4">
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-5">
        {cards.map((c) => (
          <div key={c.label} className="rounded-xl border border-slate-200 bg-white p-5">
            <p className="text-sm text-slate-500">{c.label}</p>
            <p className="mt-1 text-2xl font-semibold text-slate-800">{c.value}</p>
          </div>
        ))}
      </div>

      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-3">
          <div className="relative">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              value={query}
              onChange={(e) => { setQuery(e.target.value); setPage(1); }}
              placeholder="Search by name or email"
              className="w-64 rounded-lg border border-slate-200 bg-white py-2 pl-9 pr-3 text-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
            />
          </div>
          <select value={roleFilter} onChange={(e) => { setRoleFilter(e.target.value); setPage(1); }} aria-label="Filter by role" className="rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm">
            <option value="all">All roles</option>
            {roles.map((r) => (
              <option key={r.id} value={r.id}>{r.name}</option>
            ))}
          </select>
          <select value={statusFilter} onChange={(e) => { setStatusFilter(e.target.value as typeof statusFilter); setPage(1); }} aria-label="Filter by status" className="rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm">
            <option value="all">All statuses</option>
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
            <option value="never">Never signed in</option>
          </select>
        </div>

        <div className="flex gap-2">
          <button onClick={exportCsv} disabled={filtered.length === 0} className="flex items-center gap-2 rounded-lg border border-slate-200 bg-white px-4 py-2 text-sm font-medium text-slate-600 hover:bg-slate-50 disabled:opacity-40">
            <Download size={16} /> Export CSV
          </button>
          <button onClick={() => setEditing("new")} className="flex items-center gap-2 rounded-lg bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700">
            <Plus size={16} /> Add User
          </button>
        </div>
      </div>

      {selected.size > 0 && (
        <div className="flex flex-wrap items-center gap-3 rounded-lg bg-blue-50 px-4 py-2 text-sm text-blue-800">
          <span>{selected.size} selected</span>
          <button onClick={() => bulkSetActive(true)} className="rounded-md bg-white px-3 py-1 font-medium text-emerald-700 ring-1 ring-slate-200 hover:bg-emerald-50">Activate</button>
          <button onClick={() => bulkSetActive(false)} className="rounded-md bg-white px-3 py-1 font-medium text-amber-700 ring-1 ring-slate-200 hover:bg-amber-50">Deactivate</button>
          <button onClick={() => setSelected(new Set())} className="ml-auto text-blue-700 hover:underline">Clear selection</button>
        </div>
      )}

      {notice && <p role="status" className="rounded-lg bg-slate-800 px-4 py-2 text-sm text-white">{notice}</p>}

      <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white">
        <table className="w-full text-left text-sm">
          <thead className="bg-slate-50 text-xs uppercase text-slate-500">
            <tr>
              <th className="w-10 px-5 py-3">
                <input type="checkbox" checked={allOnPage} onChange={togglePage} aria-label="Select all users on this page" className="h-4 w-4 rounded border-slate-300 text-blue-600" />
              </th>
              {sortable("name", "User")}
              {sortable("role", "Role")}
              <th className="px-5 py-3">Phone</th>
              {sortable("lastLogin", "Last login")}
              {sortable("status", "Status")}
              <th className="px-5 py-3 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {pageRows.map((u) => (
              <tr key={u.id} className={selected.has(u.id) ? "bg-blue-50/50" : "hover:bg-slate-50"}>
                <td className="px-5 py-3">
                  <input type="checkbox" checked={selected.has(u.id)} onChange={() => toggleRow(u.id)} aria-label={`Select ${u.name}`} className="h-4 w-4 rounded border-slate-300 text-blue-600" />
                </td>
                <td className="px-5 py-3">
                  <div className="flex items-center gap-3">
                    <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-blue-50 text-sm font-semibold text-blue-600">{u.name.charAt(0).toUpperCase()}</div>
                    <div>
                      <p className="font-medium text-slate-800">
                        {u.name}
                        {u.id === me?.id && <span className="ml-2 text-xs font-normal text-slate-400">(you)</span>}
                      </p>
                      <p className="text-xs text-slate-500">{u.email}</p>
                    </div>
                  </div>
                </td>
                <td className="px-5 py-3 text-slate-700">
                  {roleName(u.roleId)}
                  {u.permissions && u.roleId !== ADMIN_ROLE_ID && <span className="ml-2 rounded bg-violet-50 px-1.5 py-0.5 text-xs text-violet-700" title="Privileges chosen for this user">custom</span>}
                </td>
                <td className="px-5 py-3 text-slate-600">{u.phone ?? "—"}</td>
                <td className="px-5 py-3 text-slate-600">
                  {shownTime(u.lastLogin)}
                  {u.mustChangePassword && <span className="ml-2 rounded bg-amber-50 px-1.5 py-0.5 text-xs text-amber-700">pwd change pending</span>}
                </td>
                <td className="px-5 py-3">
                  <span className={`rounded-full px-2.5 py-1 text-xs font-medium ${u.active ? "bg-emerald-50 text-emerald-700" : "bg-slate-100 text-slate-500"}`}>{u.active ? "Active" : "Inactive"}</span>
                </td>
                <td className="px-5 py-3">
                  <div className="flex justify-end gap-1">
                    <button onClick={() => setViewing(u)} title="View access" aria-label={`View ${u.name}`} className="rounded-md p-1.5 text-slate-500 hover:bg-blue-50 hover:text-blue-600"><Eye size={16} /></button>
                    <button onClick={() => setEditing(u)} title="Edit" aria-label={`Edit ${u.name}`} className="rounded-md p-1.5 text-slate-500 hover:bg-blue-50 hover:text-blue-600"><Pencil size={16} /></button>
                    <button onClick={() => resetPassword(u)} title="Reset password" aria-label={`Reset password for ${u.name}`} className="rounded-md p-1.5 text-slate-500 hover:bg-amber-50 hover:text-amber-600"><KeyRound size={16} /></button>
                    <button onClick={() => toggleActive(u)} title={u.active ? "Deactivate" : "Activate"} aria-label={`${u.active ? "Deactivate" : "Activate"} ${u.name}`} className="rounded-md p-1.5 text-slate-500 hover:bg-emerald-50 hover:text-emerald-600"><Power size={16} /></button>
                    <button onClick={() => remove(u)} title="Delete" aria-label={`Delete ${u.name}`} className="rounded-md p-1.5 text-slate-500 hover:bg-rose-50 hover:text-rose-600"><Trash2 size={16} /></button>
                  </div>
                </td>
              </tr>
            ))}
            {filtered.length === 0 && (
              <tr>
                <td colSpan={7} className="px-5 py-8 text-center text-slate-400">No users found.</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {filtered.length > PAGE_SIZE && (
        <div className="flex items-center justify-between text-sm text-slate-500">
          <span>
            Showing {(safePage - 1) * PAGE_SIZE + 1}–{Math.min(safePage * PAGE_SIZE, filtered.length)} of {filtered.length}
          </span>
          <div className="flex gap-2">
            <button disabled={safePage === 1} onClick={() => setPage(safePage - 1)} className="rounded-lg border border-slate-200 px-3 py-1.5 hover:bg-slate-50 disabled:opacity-40">Previous</button>
            <button disabled={safePage === pageCount} onClick={() => setPage(safePage + 1)} className="rounded-lg border border-slate-200 px-3 py-1.5 hover:bg-slate-50 disabled:opacity-40">Next</button>
          </div>
        </div>
      )}

      {editing && (
        <UserForm
          user={editing === "new" ? null : editing}
          users={users}
          roles={roles}
          isSelf={editing !== "new" && editing.id === me?.id}
          lockedAdmin={editing !== "new" && isLastActiveAdmin(editing)}
          onSave={save}
          onClose={() => setEditing(null)}
        />
      )}
      {viewing && <UserDetail user={viewing} roles={roles} onClose={() => setViewing(null)} />}
      {credentials && <CredentialsModal {...credentials} onClose={() => setCredentials(null)} />}
    </div>
  );
}
